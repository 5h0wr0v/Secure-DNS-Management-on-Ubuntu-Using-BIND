from flask import Flask, request, jsonify, render_template
import json
import datetime
from dns_server import query_dns

app = Flask(__name__)

def load_blocked_domains():
    try:
        with open('blocked_domains.json', 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return []

def save_blocked_domains(blocked_domains):
    with open('blocked_domains.json', 'w') as file:
        json.dump(blocked_domains, file)
                                                                    
def log_dns_request(domain, action):#5843
    try:
        with open('dns_logs.json', 'r') as file:
            logs = json.load(file)
    except FileNotFoundError:
        logs = []

    logs.append({
        'domain': domain,
        'action': action,
        'timestamp': datetime.datetime.now().isoformat()
    })

    with open('dns_logs.json', 'w') as file:#5843
        json.dump(logs, file)

def is_access_allowed(domain):
    try:
        with open('time_rules.json', 'r') as file:
            rules = json.load(file)
    except FileNotFoundError:
        return True  

    now = datetime.datetime.now().time()
    for rule in rules:
        if rule['domain'] == domain:
            start_time = datetime.datetime.strptime(rule['start_time'], '%H:%M').time()
            end_time = datetime.datetime.strptime(rule['end_time'], '%H:%M').time()
            return start_time <= now <= end_time
    return True

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/manage')
def manage():
    blocked_domains = load_blocked_domains()
    return render_template('manage.html', blocked_domains=blocked_domains)

@app.route('/logs')#url set (5843)
def logs():
    try:
        with open('dns_logs.json', 'r') as file:
            logs = json.load(file)
    except FileNotFoundError:
        logs = []
    return render_template('logs.html', logs=logs)

@app.route('/resolve', methods=['GET', 'POST'])

def resolve():
    domain = request.form.get('domain') or request.args.get('domain')
    action = request.form.get('action')
    
    if not domain:
        return jsonify({'error': 'Domain parameter is required'}), 400
    if action == 'block':
        blocked_domains = load_blocked_domains()
        if domain not in blocked_domains:
            blocked_domains.append(domain)
            save_blocked_domains(blocked_domains)
            log_dns_request(domain, 'blocked')
            return jsonify({'message': f'Domain {domain} has been blocked.'})
    if not is_access_allowed(domain):
        log_dns_request(domain, 'denied (time-based)')
        return jsonify({'error': 'Access to this domain is restricted by time-based rules'}), 403
    blocked_domains = load_blocked_domains()
    if domain in blocked_domains:
        log_dns_request(domain, 'blocked')
        return jsonify({'error': 'This domain is blocked by parental controls'}), 403
    ip_address = query_dns(domain)
    log_dns_request(domain, 'resolved')
    return jsonify({'domain': domain, 'ip': ip_address})

@app.route('/add_block', methods=['POST'])
def add_block():
    domain = request.form.get('domain')
    if not domain:
        return jsonify({'error': 'Domain parameter is required'}), 400

    blocked_domains = load_blocked_domains()
    if domain not in blocked_domains:
        blocked_domains.append(domain)
        save_blocked_domains(blocked_domains)
        log_dns_request(domain, 'blocked')
    return jsonify({'message': f'Domain {domain} has been blocked.'})

@app.route('/unblock', methods=['POST'])
def unblock():
    domain = request.form.get('domain')
    if not domain:
        return jsonify({'error': 'Domain parameter is required'}), 400
    
    blocked_domains = load_blocked_domains()
    if domain in blocked_domains:
        blocked_domains.remove(domain)
        save_blocked_domains(blocked_domains)
        log_dns_request(domain, 'unblocked')
    return jsonify({'message': f'Domain {domain} has been unblocked.'})

@app.route('/add_time_rule', methods=['POST'])
def add_time_rule():
    domain = request.form.get('domain')
    start_time = request.form.get('start_time')
    end_time = request.form.get('end_time')
    
    if not domain or not start_time or not end_time:
        return jsonify({'error': 'All fields are required'}), 400

    try:
        with open('time_rules.json', 'r') as file:
            rules = json.load(file)
    except FileNotFoundError:
        rules = []
    
    rules.append({
        'domain': domain,
        'start_time': start_time,
        'end_time': end_time
    })

    with open('time_rules.json', 'w') as file:
        json.dump(rules, file)
    
    return jsonify({'message': f'Time-based restrictions for {domain} have been added.'})

if __name__ == '__main__':
    app.run(debug=True)
