import socket

# Query DNS server (e.g., Google's 8.8.8.8) for a domain
def query_dns(domain):
    try:
        ip_address = socket.gethostbyname(domain)
        return ip_address
    except socket.gaierror:
        return 'Unable to resolve domain'
